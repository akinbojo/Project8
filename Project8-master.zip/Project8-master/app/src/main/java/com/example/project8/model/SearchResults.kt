package com.example.project8.model

import com.google.gson.annotations.SerializedName

data class SearchResults(@SerializedName("search")
                         val movie: Movie){

}
