package com.example.project8.model

import android.os.Parcel
import android.os.Parcelable

data class Movie(
    val Title: String?,
    val Poster: String?,
    val Year: String?,
    val imdbRating: String?,
    val imdbID: String?
) : Parcelable {


    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    ) {
    }

    override fun toString(): String {
        return "Movie(title='$Title', posterUrl='$Poster', year='$Year', rating='$imdbRating',  imdbID='$imdbID')"
    }

    override fun describeContents(): Int {
        TODO("Not yet implemented")
    }

    override fun writeToParcel(p0: Parcel, p1: Int) {
        TODO("Not yet implemented")
    }

    companion object CREATOR : Parcelable.Creator<Movie> {
        override fun createFromParcel(parcel: Parcel): Movie {
            return Movie(parcel)
        }

        override fun newArray(size: Int): Array<Movie?> {
            return arrayOfNulls(size)
        }
    }
}


