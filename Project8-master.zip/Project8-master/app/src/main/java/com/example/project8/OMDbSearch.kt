package com.example.project8

import com.example.project8.model.Movie
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query


interface OMDbSearch {

    companion object{
        private const val API_KEY = "72eb95bf"
    }

    @GET(".")
    fun getMovieDetails(
        @Query("apiKey") apiKey: String = API_KEY,
        @Query("t") imdbtitle: String
    ) : Call<Movie>
}