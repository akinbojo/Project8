package com.example.project8

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.example.project8.databinding.FragmentResultBinding


class ResultFragment : Fragment() {
    private var _binding: FragmentResultBinding? = null
    private val binding get() = _binding!!
    val args : ResultFragmentArgs by navArgs()



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentResultBinding.inflate(inflater, container, false)
        val view = binding.root
        val movie = args.movie
        val imdbLink = "https://www.imdb.com/title/${movie.imdbID}/"
        binding.feedbackButton.setOnClickListener {
            sendFeedback()
        }
        binding.tvTitle.text = movie.Title
        Glide.with(view).load(movie.Poster)
            .apply(
                RequestOptions().transform(
                    RoundedCorners(20)
                )
            )
            .into(binding.poster)
        binding.tvYear.text = movie.Year
        binding.tvRating.text = movie.imdbRating
        val linkText = SpannableStringBuilder("Click for Imdb Link")
        val clickableSpan = object : ClickableSpan(){
            override fun onClick(p0: View) {
                val intent = Intent(Intent.ACTION_VIEW)
                intent.data = Uri.parse("https://www.imdb.com/title/${movie.imdbID}/")
                startActivity(intent)
            }
        }
        linkText.append("here", clickableSpan, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        binding.tvLink.text = linkText
        binding.tvLink.movementMethod = LinkMovementMethod.getInstance()

        binding.shareButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "text/plain"
            intent.putExtra(Intent.EXTRA_TEXT, "${movie.Title} - $imdbLink")
            startActivity(Intent.createChooser(intent, "Share via"))
        }
        return view
    }

    private fun sendFeedback() {
        val intent = Intent(Intent.ACTION_SENDTO)
        intent.data = Uri.parse("mailto: ababatun@iu.edu")
        intent.putExtra(Intent.EXTRA_SUBJECT, "App Feedback")
        intent.putExtra(Intent.EXTRA_TEXT, "Add feedback text")
        startActivity(intent)
    }

}