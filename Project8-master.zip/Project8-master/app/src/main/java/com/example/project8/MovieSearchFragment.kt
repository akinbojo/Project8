package com.example.project8

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.project8.databinding.FragmentMovieSearchBinding
import com.example.project8.model.Movie
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

private const val API_KEY = "caedd47a"
private const val BASE_URL = "https://www.omdbapi.com/"
private const val TAG = "Movie Search Fragment"
class MovieSearchFragment : Fragment() {
    private var _binding: FragmentMovieSearchBinding? = null
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentMovieSearchBinding.inflate(inflater, container, false)
        val view = binding.root

        binding.submitButton.setOnClickListener {
            val query = binding.searchInput.text.toString()
            Log.w(TAG, query)
            searchMovies(query)
        }


        return view
    }

    private fun searchMovies(query: String) {
        // Create Retrofit instance
        val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        val movieAdapter = moshi.adapter(Movie::class.java)
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create())
            .build()
        val movieSearch = retrofit.create(OMDbSearch::class.java)

        // Execute search
        movieSearch.getMovieDetails(API_KEY, query).enqueue(object : Callback<Movie>{

            override fun onResponse(call: Call<Movie>, response: Response<Movie>) {
                Log.i(TAG, "onResponse $response")
                val body = response.body() ?: return
                Log.d(TAG, body.toString())
                val movie = Movie(
                    Title = body.Title,
                    Poster = body.Poster,
                    Year = body.Year,
                    imdbRating = body.imdbRating,
                    imdbID = body.imdbID
                )
                if(movie == null){
                    Log.e("Movie", "It's null ash")
                }
                if (body == null) {
                    Log.w(TAG, "Did not receive valid response body from OMDb API... exiting")
                    return
                }
                if (movie != null) {
                    showResults(movie)
                    Log.w(TAG, "The movie isn't null")
                }
                else{
                    Log.w(TAG, "The movie is null")
                }
            }

            override fun onFailure(call: Call<Movie>, t: Throwable) {
                Log.e(TAG, "onFailure $t")
            }
        })
    }

    private fun showResults(movie: Movie) {
        //movie.title?.let { Log.d("Movie Name", it) }
        if(movie != null) {
            val action = MovieSearchFragmentDirections
                .actionMovieSearchFragmentToResultFragment(movie)
            findNavController().navigate(action)
        }else{
            Log.e(TAG,"the movie object is null for some reason")
        }
    }



}