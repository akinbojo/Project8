package com.example.project8

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


private const val BASE_URL = "http://www.omdbapi.com/?apikey=caedd47a&"
private const val POSTER_URL = "http://img.omdbapi.com/?apikey=caedd47a&"

class MainActivity : AppCompatActivity() {
    val TAG = "Main Activity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

}


